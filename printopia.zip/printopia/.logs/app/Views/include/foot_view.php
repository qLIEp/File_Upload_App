        <footer>
            <p>For educational purposes only, no copyright infringement intended</p>
        </footer>
    </div> <!-- end main content -->
    </div> <!-- end d-flex -->
    </div> <!-- end container-fluid -->
</body>
</html>