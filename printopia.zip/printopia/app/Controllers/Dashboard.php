<?php
namespace App\Controllers;

use App\Models\ClientModel;
use App\Models\OrderModel;
use Cloudinary\Configuration\Configuration;
use Cloudinary\Api\Upload\UploadApi;

class Dashboard extends BaseController
{

    public function __construct()
    {
        // Python config equivalent
        Configuration::instance([
            'cloud' => [
                'cloud_name' => 'di5s79g5t',
                'api_key' => '712549991914448',
                'api_secret' => 'hk2RbTwB6Fq9tBPkhXpZ0vQ3wYk'
            ],
            'url' => ['secure' => true]
        ]);
    }

    public function index()
    {
        $clientModel = new ClientModel();
        $data['clients'] = $clientModel->findAll();
        return view('dashboard_view', $data);
    }

    // Python save_tx() logic
    public function processTransaction()
    {
        $clientModel = new ClientModel();
        $orderModel = new OrderModel();

        $cid = $this->request->getPost('client_id');
        $amt = (float) $this->request->getPost('amount');
        $type = $this->request->getPost('tx_type');

        $balanceAdjustment = ($type === 'buy') ? $amt : -$amt;
        $prefix = ($type === 'buy') ? "[CHARGE] " : "[PAYMENT] ";

        $orderModel->insert([
            'client_id' => $cid,
            'order_description' => $prefix . $this->request->getPost('desc'),
            'amount' => $amt,
            'order_date' => date('Y-m-d')
        ]);

        $clientModel->where('client_id', $cid)
            ->set('current_balance', "current_balance + $balanceAdjustment", FALSE)
            ->update();

        return redirect()->to(base_url())->with('status', 'Transaction Processed!');
    }

    // Python manual_upload() logic
    public function uploadFile()
    {
        $cid = $this->request->getPost('client_id');
        $file = $this->request->getFile('design_file');

        if ($file->isValid() && !$file->hasMoved()) {
            $uploadApi = new UploadApi();
            $result = $uploadApi->upload($file->getTempName(), [
                'folder' => "clients/client_$cid"
            ]);

            $clientModel = new ClientModel();
            $clientModel->update($cid, ['image_url' => $result['secure_url']]);
        }

        return redirect()->to(base_url())->with('status', 'File Uploaded to Cloud!');
    }

    // Python process_chat() logic (AJAX ready)
    public function chatbot()
    {
        $raw = strtolower($this->request->getPost('message'));
        $parts = explode(' ', $raw);

        if (count($parts) < 2)
            return $this->response->setJSON(['msg' => 'Format: balance [id]']);

        $cmd = $parts[0];
        $cid = $parts[1];
        $client = (new ClientModel())->find($cid);

        if (!$client)
            return $this->response->setJSON(['msg' => 'Client not found.']);

        if (str_contains($cmd, 'balance')) {
            return $this->response->setJSON(['msg' => "{$client['name']} balance: $" . number_format($client['current_balance'], 2)]);
        }
        return $this->response->setJSON(['msg' => "Unknown command."]);
    }
}