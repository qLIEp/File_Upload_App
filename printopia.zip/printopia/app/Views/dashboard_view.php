<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>FNR Graphics Pro Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .chat-area {
            height: 300px;
            overflow-y: auto;
            background: #2c3e50;
            color: #ecf0f1;
            padding: 15px;
            font-family: 'Consolas', monospace;
            border-radius: 5px;
        }

        .nav-tabs .nav-link.active {
            font-weight: bold;
            border-bottom: 3px solid #0d6efd;
        }
    </style>
</head>

<body class="bg-light">

    <div class="container mt-5">
        <div class="card shadow">
            <div class="card-header bg-dark text-white d-flex justify-content-between">
                <span>🎨 FNR Graphics Cloud System</span>
                <span id="db-indicator" class="badge bg-success">DB Online</span>
            </div>
            <div class="card-body">
                <ul class="nav nav-tabs mb-4" id="trackerTabs">
                    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#chat">🤖
                            Chatbot</button></li>
                    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tx">💸
                            Transaction</button></li>
                    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#cloud">☁️ Cloud
                            Upload</button></li>
                    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#history">🔍
                            History</button></li>
                </ul>

                <div class="tab-content">
                    <div class="tab-pane fade show active" id="chat">
                        <div class="chat-area mb-3" id="chatbox">System: Ready. Type 'balance [id]'</div>
                        <div class="input-group">
                            <input type="text" id="chatInput" class="form-control" placeholder="Type command...">
                            <button class="btn btn-primary" onclick="sendChat()">Send</button>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="tx">
                        <form action="<?= base_url('dashboard/processTransaction') ?>" method="post">
                            <div class="row g-3">
                                <div class="col-md-6"><label>Client ID</label><input type="number" name="client_id"
                                        class="form-control" required></div>
                                <div class="col-md-6">
                                    <label>Type</label>
                                    <select name="tx_type" class="form-select">
                                        <option value="buy">Buy Order (Charge)</option>
                                        <option value="pay">Payment (Credit)</option>
                                    </select>
                                </div>
                                <div class="col-12"><label>Description</label><input type="text" name="desc"
                                        class="form-control"></div>
                                <div class="col-md-6"><label>Amount ($)</label><input type="number" step="0.01"
                                        name="amount" class="form-control" required></div>
                                <div class="col-12"><button class="btn btn-success">Record Transaction</button></div>
                            </div>
                        </form>
                    </div>

                    <div class="tab-pane fade" id="cloud">
                        <form action="<?= base_url('dashboard/uploadFile') ?>" method="post"
                            enctype="multipart/form-data">
                            <div class="mb-3"><label>Client ID</label><input type="number" name="client_id"
                                    class="form-control" required></div>
                            <div class="mb-3"><label>Select Design File</label><input type="file" name="design_file"
                                    class="form-control" required></div>
                            <button class="btn btn-info">Upload to Cloudinary</button>
                        </form>
                    </div>

                    <div class="tab-pane fade" id="history">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Balance</th>
                                    <th>Cloud Link</th>
                                </tr>
                            </thead>
                            <tbody>
                                    <?php foreach ($clients as $c): ?>
                                    <tr>
                                        <td><?= $c['client_id'] ?></td>
                                        <td><?= $c['name'] ?></td>
                                        <td class="<?= $c['current_balance'] > 0 ? 'text-danger' : 'text-success' ?>">
                                            $<?= number_format($c['current_balance'], 2) ?>
                                        </td>
                                        <td><a href="<?= $c['image_url'] ?>" target="_blank"
                                                class="btn btn-sm btn-link">View File</a></td>
                                    </tr>
                                    <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        async function sendChat() {
            const input = document.getElementById('chatInput');
            const box = document.getElementById('chatbox');
            const msg = input.value;
            if (!msg) return;

            box.innerHTML += `<div class="text-info">You: ${msg}</div>`;

            const formData = new FormData();
            formData.append('message', msg);

            const response = await fetch('<?= base_url('dashboard/chatbot') ?>', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();
            box.innerHTML += `<div class="text-warning">Bot: ${data.msg}</div><br>`;
            input.value = '';
            box.scrollTop = box.scrollHeight;
        }
    </script>
</body>

</html>