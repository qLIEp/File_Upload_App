<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Dashboard::index');
$routes->post('dashboard/processTransaction', 'Dashboard::processTransaction');
$routes->post('dashboard/uploadFile', 'Dashboard::uploadFile');
$routes->post('dashboard/chatbot', 'Dashboard::chatbot');