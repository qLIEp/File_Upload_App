<?php
namespace App\Controllers;

use Cloudinary\Configuration\Configuration;
use Cloudinary\Api\Upload\UploadApi;
use Cloudinary\Api\Admin\AdminApi;
use Exception;

class CloudManager extends BaseController
{

    public function __construct()
    {
        Configuration::instance([
            'cloud' => [
                'cloud_name' => 'di5s79g5t',
                'api_key' => '712549991914448',
                'api_secret' => 'hk2RbTwB6Fq9tBPkhXpZ0vQ3wYk'
            ],
            'url' => ['secure' => true]
        ]);
    }

    public function index()
    {
        $adminApi = new AdminApi();
        $currentPath = $this->request->getGet('folder') ?: '';

        try {
            // Fetch Folders
            $folderResponse = empty($currentPath) ? $adminApi->rootFolders() : $adminApi->subFolders($currentPath);
            $data['folders'] = $folderResponse['folders'];

            // Fetch Files
            $assetParams = ['max_results' => 50, 'type' => 'upload'];
            if (!empty($currentPath)) {
                $assetParams['prefix'] = $currentPath . '/';
            }
            $assetResponse = $adminApi->assets($assetParams);
            $data['files'] = $assetResponse['resources'];

        } catch (Exception $e) {
            $data['folders'] = [];
            $data['files'] = [];
        }

        $data['currentPath'] = $currentPath;
        return view('cloud_view', $data);
    }

    public function upload()
    {
        $file = $this->request->getFile('user_file');
        $folder = $this->request->getPost('target_folder') ?: 'uploads';

        if ($file && $file->isValid()) {
            $uploadApi = new UploadApi();
            $uploadApi->upload($file->getTempName(), [
                'folder' => $folder,
                'use_filename' => true,      // Keeps original filename
                'unique_filename' => false,  // Does not add random suffix
                'resource_type' => 'auto'
            ]);
            return redirect()->to(base_url("cloudmanager?folder=$folder"));
        }
    }
}