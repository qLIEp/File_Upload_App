<!DOCTYPE html>
<html lang="en">

<head>
    <title>Cloud File Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .file-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 15px;
        }

        .item-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 10px;
            text-align: center;
            background: #fff;
            cursor: pointer;
            transition: 0.2s;
        }

        .item-card:hover {
            border-color: #007bff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .preview {
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f8f9fa;
            border-radius: 4px;
            margin-bottom: 8px;
        }

        .preview img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        .name-label {
            font-size: 12px;
            font-weight: bold;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
    </style>
</head>

<body class="bg-light p-4">

    <div class="container bg-white p-4 shadow-sm rounded">
        <h4 class="mb-4">Cloudinary Explorer</h4>

        <form action="<?= base_url('cloudmanager/upload') ?>" method="post" enctype="multipart/form-data"
            class="row g-2 mb-4">
            <div class="col-md-5">
                <input type="file" name="user_file" class="form-control form-control-sm" required>
            </div>
            <div class="col-md-4">
                <input type="text" name="target_folder" class="form-control form-control-sm"
                    placeholder="Destination Folder">
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-sm btn-primary w-100">Upload File</button>
            </div>
        </form>

        <p class="text-muted small">Location: /<?= $currentPath ?: 'root' ?></p>

        <div class="file-grid">
            <?php foreach ($folders as $f): ?>
                <a href="<?= base_url('cloudmanager?folder=' . $f['path']) ?>" class="text-decoration-none text-dark">
                    <div class="item-card">
                        <div class="preview" style="font-size: 40px;">📂</div>
                        <div class="name-label"><?= $f['name'] ?></div>
                    </div>
                </a>
            <?php endforeach; ?>

            <?php foreach ($files as $file): ?>
                <div class="item-card" onclick="window.open('<?= $file['secure_url'] ?>', '_blank')">
                    <div class="preview">
                        <?php if ($file['resource_type'] == 'image'): ?>
                            <img src="<?= $file['secure_url'] ?>">
                        <?php else: ?>
                            <span style="font-size: 35px;">📄</span>
                        <?php endif; ?>
                    </div>
                    <div class="name-label"><?= $file['public_id'] ?></div>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if (!$currentPath == ''): ?>
            <div class="mt-4">
                <a href="<?= base_url('cloudmanager') ?>" class="btn btn-sm btn-outline-secondary">Back to Root</a>
            </div>
        <?php endif; ?>
    </div>

</body>

</html>