<?php
namespace App\Models;
use CodeIgniter\Model;

class ClientModel extends Model
{
    protected $table = 'clients';
    protected $primaryKey = 'client_id';
    protected $allowedFields = ['name', 'email', 'current_balance', 'image_url', 'last_invoice_url'];
}