<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'CloudManager::index');
// Define the CloudManager routes
$routes->get('cloudmanager', 'CloudManager::index');
$routes->post('cloudmanager/upload', 'CloudManager::upload');

$routes->post('dashboard/manualUpload', 'CloudManager::upload');